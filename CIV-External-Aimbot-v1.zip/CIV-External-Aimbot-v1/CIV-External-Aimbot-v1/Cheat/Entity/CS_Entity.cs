﻿//
// Entity-Class definiert
//

using System;
using System.IO;
using System.Text.RegularExpressions;


class Entity
{
    // Vars
    public int pBase, pBoneBase, pEnginePointer;
    public int IHealth, ITeam, IFlags, IWeaponID;
    public double[] vecHead, vecOrigin, EnginePos, vAngs, vPunch, vOldPunch = new double[3];
    bool bIsAlive;
    public CGlobalVarsBase pGlobals;
}

class CGlobalVarsBase
{
    public static float realtime;
    public static int framecount;
    public static float absolute_frametime;
    public static float absolute_framestarttimestddev;
    public static float curtime;
    public static float frameTime;
    public static int maxClients;
    public static int tickcount;
    public static float interval_per_tick;
    public static float interpolation_amount;
    public static int simThicksThisFrame;
    public static int network_protocol;
};

class CGlobalVarsBase_muster
{
    public static float realtime;
    public static int framecount;
    public static float absolute_frametime;
    public static float absolute_framestarttimestddev;
    public static float curtime;
    public static float frameTime;
    public static int maxClients;
    public static int tickcount;
    public static float interval_per_tick;
    public static float interpolation_amount;
    public static int simThicksThisFrame;
    public static int network_protocol;
}