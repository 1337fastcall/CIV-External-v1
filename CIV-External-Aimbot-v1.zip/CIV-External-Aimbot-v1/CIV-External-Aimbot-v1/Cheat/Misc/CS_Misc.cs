﻿//
// Misc-Class definiert
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

class CMisc
{

    public static void Bunnyhop()
    {
        


    }

    public static void DisplayLocalPlayerInfo()
    {
        Entity pLocalPlayer = new Entity();

        pLocalPlayer.pBase = CMemoryHandler.readInt(CMemoryHandler.GetClientDll() + 0xA68A14);
        pLocalPlayer.IHealth = CMemoryHandler.readInt(pLocalPlayer.pBase + 0xFC);
        pLocalPlayer.ITeam = CMemoryHandler.readInt(pLocalPlayer.pBase + 0xF0);
        int n_tick = CMemoryHandler.readInt(pLocalPlayer.pBase + 0x17C0);
        pLocalPlayer.IFlags = CMemoryHandler.readInt(pLocalPlayer.pBase + 0x100);


        int weapon_handle = CMemoryHandler.readInt(pLocalPlayer.pBase + 0x12C0);
        int index = weapon_handle & 0xFFF;
        int weaponbase = CMemoryHandler.readInt(CMemoryHandler.GetClientDll() + 0x4A0B0C4 + ((index - 1) * 0x10));
        pLocalPlayer.IWeaponID = CMemoryHandler.readInt(weaponbase + 0x1684);

        pLocalPlayer.vecOrigin = new double[3];
        pLocalPlayer.vecOrigin[0] = CMemoryHandler.readDouble2((pLocalPlayer.pBase + 0x134));
        pLocalPlayer.vecOrigin[1] = CMemoryHandler.readDouble2((pLocalPlayer.pBase + 0x134 + 4));
        pLocalPlayer.vecOrigin[2] = CMemoryHandler.readDouble2((pLocalPlayer.pBase + 0x134 + 8));


        pLocalPlayer.pEnginePointer = CMemoryHandler.readInt(CMemoryHandler.GetEngineDll() + (int)Offsets.EnginePointer);

        pLocalPlayer.EnginePos = new double[3];
        pLocalPlayer.EnginePos[0] = CMemoryHandler.readDouble2(CMemoryHandler.GetEngineDll() + (int)Offsets.pEnginePosition);
        pLocalPlayer.EnginePos[1] = CMemoryHandler.readDouble2(CMemoryHandler.GetEngineDll() + (int)Offsets.pEnginePosition + 4);
        pLocalPlayer.EnginePos[2] = CMemoryHandler.readDouble2(CMemoryHandler.GetEngineDll() + (int)Offsets.pEnginePosition + 8);

        pLocalPlayer.vAngs = new double[3];
        pLocalPlayer.vAngs[0] = CMemoryHandler.readDouble2(pLocalPlayer.pEnginePointer + 0x4C90);
        pLocalPlayer.vAngs[1] = CMemoryHandler.readDouble2(pLocalPlayer.pEnginePointer + 0x4C90 + 4);
        pLocalPlayer.vAngs[2] = CMemoryHandler.readDouble2(pLocalPlayer.pEnginePointer + 0x4C90 + 8);


        
        

        

        Console.WriteLine("LocalPlayer Information:\n");
        Console.WriteLine(" -> Health: " + pLocalPlayer.IHealth);
        Console.WriteLine(" -> Team: " + pLocalPlayer.ITeam);
        Console.WriteLine(" -> m_nTickbase: " + n_tick);
        Console.WriteLine(" -> WeaponID: " + pLocalPlayer.IWeaponID);


        if (Convert.ToBoolean(pLocalPlayer.IFlags & (1 << 0)))
        {
            Console.WriteLine(" -> Flags: On Ground");
        }
        else
        {
            Console.WriteLine(" -> Flags: In Air");
        }

        Console.Write("\n");
        Console.WriteLine(" -> Position: ");
        Console.WriteLine("       X:    " + pLocalPlayer.EnginePos[0]);
        Console.WriteLine("       Y:    " + pLocalPlayer.EnginePos[1]);
        Console.WriteLine("       Z:    " + pLocalPlayer.EnginePos[2]);

        Console.Write("\n");
        Console.WriteLine(" -> ViewAngles: ");
        Console.WriteLine("       X:    " + pLocalPlayer.vAngs[0]);
        Console.WriteLine("       Y:    " + pLocalPlayer.vAngs[1]);
        Console.WriteLine("       Z:    " + pLocalPlayer.vAngs[2]);

        // <testing>
        Console.WriteLine("interval_per_tick: " + CGlobalVarsBase.interval_per_tick);
        // </testing>
    }
}